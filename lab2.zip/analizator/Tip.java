public enum Tip {
    STANJE,
    CVOR
}
